#Import the necessary library, method, python file
from tweepy.streaming import StreamListener
from tweepy import OAuthHandler
from tweepy import Stream
import json

consumer_key='WAqEBRmONm5CLavo2sFm1YNRA'
consumer_secret='8HpTSValZ6CyWHJJ46WS9uFd7rAUdDxmvmSvEK3pg9K96lq9F0'
access_token='3648732853-YyYQ40PnTUXReEa8VzpcHqLBg20mFRgbKoIlXue'
access_token_secret='AVVBrkO3sfUaFfGrdYZ32mv7j7N9RlXTEfEMyU8ymh2au'


5#This class is use for print tweet in json format
class StdOutListener(StreamListener):

  5  def on_data(self, data):
        try:
            
            jsonData = json.loads(data)
            text = jsonData['text'].lower() #In this statement we pick only text key value and convert it to lower form
            lang = jsonData['lang']#This statement fatch language of the tweet such as en,kl, etc.
            if lang=='en':
               
                    txt=text.split("http")
                    print(txt[0]) #print the filter tweets 
            return True

        except:
            return True
    def on_error(self, status):
         print (status)


if __name__ == '__main__':
    
    #This handles Twitter authetification and the connection to Twitter Streaming API
    l = StdOutListener()
    auth = OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    stream = Stream(auth, l)
    #This line filter Twitter Streams to capture data by the keywords
    stream.filter(track=['modi'])

