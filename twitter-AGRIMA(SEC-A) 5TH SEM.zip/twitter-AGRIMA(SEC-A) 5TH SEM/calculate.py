from sentiment import *
newDict={}
with open('AFINN-111 (2).txt', 'r') as f:
    for line in f:
       splitLine = line.split()
       newDict[(splitLine[0])] = ",".join(splitLine[1:])

       
with open('output.txt', 'r') as f:
      
      for line in f:
          score=0.0
          value=afinn.score(line)
          score = score+ value
          tscore=(score/len(newDict))
          if tscore >0:
              em="pos"
          elif tscore<0:
              em="neg"
          else:
              em="neutral"
      
          print("%s \n%f :: %s \n" %(line,tscore,em))
             
