from afinn import Afinn
afinn=Afinn()

























newDict={}

def sent(file):     
   try:
      for line in file:
         word=line.split()
         tscore=0.0
         for i in range(len(word)):
            score = 0.0
            if word[i] in newDict:
               var=word[i]
               score = score+ int(newDict[var])
               tscore=(score/len(newDict))
         print("%s = %f" %(line,tscore))
         return True
   except:
         True























